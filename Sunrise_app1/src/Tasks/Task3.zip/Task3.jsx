import React, { useEffect, useRef, useState } from 'react'
import axios from 'axios'

const Task3 = () => {

    const name = useRef(null);
    const type = useRef(null);
    const balance = useRef(null);
    const submitButtonRef = useRef(null);
    const [res,setRes]=useState([]);

    const url=`http://localhost:2000`;

    const [input1, setInput1] = useState('');
    const [input2, setInput2] = useState('');
    const [input3, setInput3] = useState('');
    
    // State to manage the initial button state
    const [isButtonDisabled, setIsButtonDisabled] = useState(true);
    
    const handleInputChange = () => {
      const Field1 = name.current.value;
      const Field2 = type.current.value;
      const Field3 = balance.current.value;
  
      setInput1(Field1);
      setInput2(Field2);
      setInput3(Field3)
      setIsButtonDisabled(Field1.trim() === '' || Field2.trim() === '' || Field3.trim() === '');
    };
  
    useEffect(() => {
      // Disable the button initially
      setIsButtonDisabled(true);
    }, []);
    
    const postdata=async()=>{
        const data=await axios.post(url+`/post`,{
            name:name.current.value,
            type:type.current.value,
            balance:balance.current.value
        });
        console.log(data);
        getdata();
    }

    useEffect(()=>{
        getdata();
    },[])

    const getdata=async ()=>{
        const data=await axios.get(url+`/get`);
        setRes(data.data);
    }

    const updatedata=async (accNo)=>{
        const data=await axios.put(url+`/update`,{accNo:accNo});
        getdata();
    }
  return (
    <>
  
      Name:<input type="text" ref={name} onChange={handleInputChange}/><br/>
      Type:<input type="text" ref={type} onChange={handleInputChange}/><br />
      Balance:<input type="text" ref={balance} onChange={handleInputChange}/><br />
      <button type="button" onClick={postdata} ref={submitButtonRef} disabled={isButtonDisabled}>Submit</button>

      <div className='table'>
      <table>
        <thead>
        <tr>
            <th>accNo</th>
            <th>name</th>
            <th>type</th>
            <th>status</th>
            <th>balance</th>
        </tr>
        </thead>
        <tbody>
          {
            res[0] ? (
              
                res.map((el)=>{
                  return(
                    <tr>
                      <td>{el.accNo}</td>
                      <td>{el.name}</td>
                      <td>{el.type}</td>
                      <td>{el.status}</td>
                      <td>{el.balance}</td>
                      <td>
                        <button onClick={()=>updatedata(el.accNo)}>edit</button>
                        <button >delete</button>
                      </td>
                    </tr>
                  )
                })
              
            ): (
              <p>No data</p>
            )
          }
        </tbody>
        <tfoot></tfoot>
      </table>
      </div>
    </>
  )
}

export default Task3
