// import React, { createContext } from 'react';

// const global = createContext();

// export  default global ;



import React, { createContext } from 'react'

const global=createContext();

const amt=createContext();

export  {global, amt};
